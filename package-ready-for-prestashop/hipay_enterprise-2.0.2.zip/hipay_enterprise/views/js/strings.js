
/**
 * HiPay Enterprise SDK Prestashop
 *
 * 2017 HiPay
 *
 * NOTICE OF LICENSE
 *
 * @author    HiPay <support.tpp@hipay.com>
 * @copyright 2017 HiPay
 * @license   https://github.com/hipay/hipay-enterprise-sdk-prestashop/blob/master/LICENSE.md
 */
var i18nCardNumber = 'Card Number';
var i18nNameOnCard = 'name on card';
var i18nDate = 'MM / YY';
var i18nCVC = 'CVC';
var i18nCVCLabel = 'What is CVC ?';
